import base64
import json
import os
import urllib.error
import urllib.request
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parent
TEXT_MODEL = os.getenv('JARVIS_TEXT_MODEL', 'qwen3:1.7b')
VISION_MODEL = os.getenv('JARVIS_VISION_MODEL', 'moondream')
OLLAMA_URL = 'http://127.0.0.1:11434/api/chat'
MAX_REQUEST = 14 * 1024 * 1024

class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path not in ('/', '/index.html'):
            return self.send_error(404)
        data = (ROOT / 'index.html').read_bytes()
        self.send_response(200)
        self.send_header('Content-Type', 'text/html; charset=utf-8')
        self.send_header('Content-Length', str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_POST(self):
        if self.path != '/api/chat':
            return self.send_error(404)
        try:
            length = int(self.headers.get('Content-Length', '0'))
            if not 0 < length <= MAX_REQUEST:
                return self.reply(413, {'error': 'Request too large (max 14 MB).'})
            payload = json.loads(self.rfile.read(length))
            messages = payload.get('messages')
            if not isinstance(messages, list) or not 0 < len(messages) <= 60:
                return self.reply(400, {'error': 'Invalid message history.'})
            clean = []
            has_image = False
            for item in messages:
                if not isinstance(item, dict) or item.get('role') not in ('user', 'assistant'):
                    return self.reply(400, {'error': 'Invalid role.'})
                content = item.get('content', '')
                if not isinstance(content, str) or len(content) > 12000:
                    return self.reply(400, {'error': 'Invalid message content.'})
                entry = {'role': item['role'], 'content': content}
                images = item.get('images', [])
                if images:
                    if item['role'] != 'user' or not isinstance(images, list) or len(images) > 1:
                        return self.reply(400, {'error': 'One photo per user message.'})
                    img = images[0]
                    if not isinstance(img, str) or len(img) > 11 * 1024 * 1024:
                        return self.reply(413, {'error': 'Photo too large.'})
                    try:
                        decoded = base64.b64decode(img, validate=True)
                    except Exception:
                        return self.reply(400, {'error': 'Invalid image encoding.'})
                    if len(decoded) > 8 * 1024 * 1024 or not (decoded.startswith(b'\xff\xd8\xff') or decoded.startswith(b'\x89PNG\r\n\x1a\n') or decoded.startswith(b'RIFF') and decoded[8:12] == b'WEBP'):
                        return self.reply(400, {'error': 'Only JPG, PNG or WEBP up to 8 MB.'})
                    entry['images'] = [img]
                    has_image = True
                clean.append(entry)
            if clean[-1]['role'] != 'user':
                return self.reply(400, {'error': 'Last message must be user.'})
            model = VISION_MODEL if has_image else TEXT_MODEL
            body = json.dumps({'model': model, 'messages': [
                {'role': 'system', 'content': 'You are JARVIS, a helpful text-only assistant. Reply in the user language. When given images, describe only what you can see and say when uncertain.'},
                *clean], 'stream': False, 'think': False}).encode('utf-8')
            req = urllib.request.Request(OLLAMA_URL, data=body, headers={'Content-Type': 'application/json'})
            with urllib.request.urlopen(req, timeout=240) as res:
                result = json.load(res)
            answer = result.get('message', {}).get('content', '').strip()
            self.reply(200, {'answer': answer or 'No response returned.', 'model': model})
        except urllib.error.HTTPError as exc:
            detail = exc.read(1500).decode('utf-8', 'replace')
            self.reply(502, {'error': f'Ollama error ({exc.code}): {detail}. Check installed models with: ollama list'})
        except urllib.error.URLError:
            self.reply(503, {'error': 'Ollama not running. Start Ollama and check: ollama list'})
        except Exception as exc:
            self.reply(500, {'error': str(exc)[:250]})

    def reply(self, status, payload):
        body = json.dumps(payload, ensure_ascii=False).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Cache-Control', 'no-store')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

if __name__ == '__main__':
    url = 'http://127.0.0.1:8765'
    server = ThreadingHTTPServer(('127.0.0.1', 8765), Handler)
    print('JARVIS 6.1 running at', url)
    print('Text model:', TEXT_MODEL, '| Photo model:', VISION_MODEL)
    print('Press Ctrl+C to stop')
    webbrowser.open(url)
    server.serve_forever()
