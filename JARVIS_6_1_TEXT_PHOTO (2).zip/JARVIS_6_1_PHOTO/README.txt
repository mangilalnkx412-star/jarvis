JARVIS 6.1 - ChatGPT-style Text + Photo (Windows 11)

1. Install Ollama from its official website if needed.
2. In PowerShell:
   ollama pull qwen3:1.7b
   ollama pull moondream
3. Double-click START_JARVIS.bat (Python must be installed).
4. Open http://127.0.0.1:8765 if browser does not open automatically.
5. Type messages, or click + Photo to attach one JPG/PNG/WEBP.

No microphone or voice features.
Photo requests use moondream; text-only requests use qwen3:1.7b.
Photo model needs extra RAM; performance on 8 GB systems may be slow.
Chats and photo thumbnails are stored in this browser's localStorage, subject to browser storage limits. Keep copies of important information elsewhere.
To stop, close the terminal or press Ctrl+C.
If port 8765 is in use, stop the previous JARVIS instance first.
Privacy: Ollama requests are sent to the local Ollama server (127.0.0.1). No cloud API is configured.
